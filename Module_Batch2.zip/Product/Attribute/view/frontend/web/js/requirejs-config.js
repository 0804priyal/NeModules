var config = {
    map: {
        '*': {
            module: 'Product_Attribute/js/modal-form',
        }
    }
};