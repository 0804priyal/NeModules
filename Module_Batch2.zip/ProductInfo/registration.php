<?php
use Magento\Framework\Component\ComponentRegistrar as ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, "Nethues_ProductInfo",__DIR__);