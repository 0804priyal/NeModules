var config = {
    map: {
        '*': {
            module: 'Sample_Popupcreation/js/modal-form',
        }
    }
};