<?php   
\Magento\Framework\Component\ComponentRegistrar::register(  
	\Magento\Framework\Component\ComponentRegistrar::MODULE,  'Bizspice_QuickView',  __DIR__  );