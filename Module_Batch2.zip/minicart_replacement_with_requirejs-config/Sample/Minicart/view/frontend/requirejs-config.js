var config = {
    map: {
        '*': {
            'Magento_Checkout/template/minicart/content.html': 'Sample_Minicart/template/minicart/content.html'

        },
    }
};