var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Sv_Testing/js/model/shipping-save-processor/default'
        }
    }
};