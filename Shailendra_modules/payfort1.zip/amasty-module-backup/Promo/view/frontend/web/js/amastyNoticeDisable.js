//disable mixins
window.amasty_notice_disabled = true;